package com.speedata.uhf;

import android.content.Context;
import android.os.ServiceManager;
/**
 * ----------Dragon be here!----------/
 * 　　　┏┓　　　┏┓
 * 　　┏┛┻━━━┛┻┓
 * 　　┃　　　　　　　┃
 * 　　┃　　　━　　　┃
 * 　　┃　┳┛　┗┳　┃
 * 　　┃　　　　　　　┃
 * 　　┃　　　┻　　　┃
 * 　　┃　　　　　　　┃
 * 　　┗━┓　　　┏━┛
 * 　　　　┃　　　┃神兽保佑
 * 　　　　┃　　　┃代码无BUG！
 * 　　　　┃　　　┗━━━┓
 * 　　　　┃　　　　　　　┣┓
 * 　　　　┃　　　　　　　┏┛
 * 　　　　┗┓┓┏━┳┓┏┛
 * 　　　　　┃┫┫　┃┫┫
 * 　　　　　┗┻┛　┗┻┛
 * ━━━━━━神兽出没━━━━━━
 *
 * @author :Reginer in  2017/4/20 15:23.
 *         联系方式:QQ:282921012
 *         功能描述:
 */
public class IUHFService {
    private IUhfManager uhfManager;

    private IUHFService() {
        uhfManager = IUhfManager.Stub.asInterface(ServiceManager.getService
                (Context.UHF_SERVICE));
    }

    private static IUHFService sUhfManager;

    public static IUHFService getUHFService(Context context) {
        if (sUhfManager == null) {
            sUhfManager = new IUHFService();
        }
        return sUhfManager;
    }

   public IUHFService(Context mContext, IUhfManager uhfManager) {
        this.uhfManager = uhfManager;
    }

}
