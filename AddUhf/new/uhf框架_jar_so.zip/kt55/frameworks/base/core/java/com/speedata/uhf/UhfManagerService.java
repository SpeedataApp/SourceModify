package com.speedata.uhf;

import android.content.Context;
import android.os.RemoteException;
import com.alibaba.fastjson.JSON;
import org.greenrobot.eventbus.EventBus;

/**
 * ----------Dragon be here!----------/
 * 　　　┏┓　　　┏┓
 * 　　┏┛┻━━━┛┻┓
 * 　　┃　　　　　　　┃
 * 　　┃　　　━　　　┃
 * 　　┃　┳┛　┗┳　┃
 * 　　┃　　　　　　　┃
 * 　　┃　　　┻　　　┃
 * 　　┃　　　　　　　┃
 * 　　┗━┓　　　┏━┛
 * 　　　　┃　　　┃神兽保佑
 * 　　　　┃　　　┃代码无BUG！
 * 　　　　┃　　　┗━━━┓
 * 　　　　┃　　　　　　　┣┓
 * 　　　　┃　　　　　　　┏┛
 * 　　　　┗┓┓┏━┳┓┏┛
 * 　　　　　┃┫┫　┃┫┫
 * 　　　　　┗┻┛　┗┻┛
 * ━━━━━━神兽出没━━━━━━
 *
 * @author :Reginer in  2017/4/20 15:31.
 *         联系方式:QQ:282921012
 *         功能描述:
 */
public class UhfManagerService extends IUhfManager.Stub {

    private Context mContext;

    public UhfManagerService(Context context) {
        mContext = context;
    }

    @Override
    public int openDev() throws RemoteException {
        return 0;
    }

    @Override
    public void closeDev() throws RemoteException {

    }

    @Override
    public void inventoryStart() throws RemoteException {

    }

    @Override
    public void inventoryStop() throws RemoteException {

    }

    @Override
    public byte[] readAreaByte(int area, int addr, int count, int pwd) throws RemoteException {
        return new byte[0];
    }

    @Override
    public String readArea(int area, String strAddr, String strCount, String strPwd) throws RemoteException {
        return null;
    }

    @Override
    public int writeArea(int area, String addr, String pwd, String count, String content) throws RemoteException {
        return 0;
    }

    @Override
    public int writeAreaByte(int area, int addr, int pwd, byte[] content) throws RemoteException {
        return 0;
    }

    @Override
    public int selectCard(String epc) throws RemoteException {
        return 0;
    }

    @Override
    public int setAntennaPower(int power) throws RemoteException {
        return 0;
    }

    @Override
    public int getAntennaPower() throws RemoteException {
        return 0;
    }

    @Override
    public int setFreqRegion(int region) throws RemoteException {
        return 0;
    }

    @Override
    public int getFreqRegion() throws RemoteException {
        return 0;
    }

    @Override
    public int setPassword(int which, String curPwd, String newPwd) throws RemoteException {
        return 0;
    }

    @Override
    public int setLock(int type, int area, int pwd) throws RemoteException {
        return 0;
    }
}
